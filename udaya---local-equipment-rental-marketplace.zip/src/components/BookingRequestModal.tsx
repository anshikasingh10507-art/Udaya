import React, { useState } from 'react';
import { EquipmentItem, BookingRequest } from '../types';
import { X, CheckCircle, ShieldCheck, ArrowRight, User, Phone, Briefcase, FileText } from 'lucide-react';

interface BookingRequestModalProps {
  item: EquipmentItem | null;
  initialDays: number;
  startDate: string;
  includeOperator: boolean;
  onClose: () => void;
  onSubmitBooking: (request: Omit<BookingRequest, 'id' | 'createdAt' | 'status'>) => string; // returns created requestId
  onNavigateToOwnerHub: () => void;
}

export const BookingRequestModal: React.FC<BookingRequestModalProps> = ({
  item,
  initialDays,
  startDate,
  includeOperator,
  onClose,
  onSubmitBooking,
  onNavigateToOwnerHub,
}) => {
  if (!item) return null;

  // Form inputs
  const [renterName, setRenterName] = useState('');
  const [renterPhone, setRenterPhone] = useState('+91 ');
  const [renterBusiness, setRenterBusiness] = useState('');
  const [projectNote, setProjectNote] = useState('');
  const [submittedRequestId, setSubmittedRequestId] = useState<string | null>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // Cost estimates
  const rentalSubtotal = item.dailyRate * initialDays;
  const operatorCost = includeOperator && item.operatorProvided ? 500 * initialDays : 0;
  const grandTotal = rentalSubtotal + operatorCost + item.securityDeposit;

  const validate = () => {
    const errs: { [key: string]: string } = {};
    if (!renterName.trim()) errs.renterName = 'Please enter your full name';
    if (!renterPhone.trim() || renterPhone.trim().length < 10) {
      errs.renterPhone = 'Please provide a valid 10-digit phone number';
    }
    if (!projectNote.trim()) {
      errs.projectNote = 'Please describe your project location or intended use';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const newId = onSubmitBooking({
      equipmentId: item.id,
      equipmentTitle: item.title,
      equipmentImageUrl: item.imageUrl,
      ownerBusiness: item.ownerBusiness,
      renterName: renterName.trim(),
      renterPhone: renterPhone.trim(),
      renterBusiness: renterBusiness.trim() || 'Individual Contractor',
      startDate,
      durationDays: initialDays,
      dailyRate: item.dailyRate,
      estimatedRentalTotal: rentalSubtotal + operatorCost,
      securityDeposit: item.securityDeposit,
      estimatedGrandTotal: grandTotal,
      projectNote: projectNote.trim(),
    });

    setSubmittedRequestId(newId);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div
        className="relative bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-stone-200 overflow-hidden my-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-stone-50/70">
          <div>
            <h3 className="text-base font-bold text-stone-900">
              {submittedRequestId ? 'Booking Request Submitted' : 'Submit Booking Request'}
            </h3>
            <p className="text-xs text-stone-500">
              Direct connection with {item.ownerBusiness}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submittedRequestId ? (
          /* Success Screen */
          <div className="p-6 sm:p-8 space-y-6 text-center">
            <div className="w-16 h-16 bg-emerald-50 text-emerald-800 rounded-full flex items-center justify-center mx-auto border border-emerald-200">
              <CheckCircle className="w-9 h-9" />
            </div>

            <div className="space-y-1.5">
              <span className="text-xs font-semibold text-emerald-900 uppercase tracking-wider">
                Booking Reference #{submittedRequestId}
              </span>
              <h4 className="text-xl font-extrabold text-stone-900">
                Request Sent to {item.ownerBusiness}
              </h4>
              <p className="text-xs text-stone-600 max-w-md mx-auto leading-relaxed">
                The equipment owner has received your request for <strong>{initialDays} {initialDays === 1 ? 'day' : 'days'}</strong> starting <strong>{startDate}</strong>. They will review availability and coordinate physical pickup terms.
              </p>
            </div>

            {/* Pitch demo helper box */}
            <div className="p-4 bg-amber-50/80 rounded-xl border border-amber-200 text-left text-xs text-stone-700 space-y-2">
              <div className="flex items-center gap-1.5 font-bold text-amber-950">
                <ShieldCheck className="w-4 h-4 text-amber-800" />
                Startup Pitch Prototype Note
              </div>
              <p className="leading-relaxed">
                This request is now logged in the <strong>Owner Hub</strong>. You can switch to the Owner View right now to see how the owner accepts or coordinates this request.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                onClick={onClose}
                className="w-full sm:w-auto px-5 py-2.5 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors cursor-pointer"
              >
                Done & Return to Catalog
              </button>
              <button
                onClick={() => {
                  onClose();
                  onNavigateToOwnerHub();
                }}
                className="w-full sm:w-auto px-6 py-2.5 text-xs font-bold text-white bg-emerald-900 hover:bg-emerald-950 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm active:scale-[0.98]"
              >
                <span>View Request in Owner Hub</span>
                <ArrowRight className="w-4 h-4 text-amber-400" />
              </button>
            </div>
          </div>
        ) : (
          /* Form Screen */
          <form onSubmit={handleSubmit} className="p-6 space-y-5">
            {/* Equipment Snapshot */}
            <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200/80 flex items-center gap-3">
              <img
                src={item.imageUrl}
                alt={item.title}
                className="w-14 h-14 object-cover rounded-lg border border-stone-200 shrink-0"
              />
              <div className="flex-1 min-w-0 text-xs">
                <div className="font-bold text-stone-900 truncate">{item.title}</div>
                <div className="text-stone-500 mt-0.5">
                  {initialDays} {initialDays === 1 ? 'day' : 'days'} · From {startDate}
                </div>
                <div className="text-emerald-950 font-semibold mt-0.5">
                  Total Estimate: ₹{grandTotal.toLocaleString('en-IN')}{' '}
                  <span className="text-stone-400 font-normal">
                    (incl. ₹{item.securityDeposit.toLocaleString('en-IN')} deposit)
                  </span>
                </div>
              </div>
            </div>

            {/* Inputs */}
            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-stone-800 mb-1">
                  Your Full Name <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={renterName}
                    onChange={(e) => setRenterName(e.target.value)}
                    placeholder="e.g. Suresh Kumar"
                    className="w-full pl-9 pr-3 py-2 bg-white border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30"
                  />
                </div>
                {errors.renterName && (
                  <p className="text-[11px] text-red-600 mt-1">{errors.renterName}</p>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-800 mb-1">
                    Mobile Number <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={renterPhone}
                      onChange={(e) => setRenterPhone(e.target.value)}
                      placeholder="+91 98450 12345"
                      className="w-full pl-9 pr-3 py-2 bg-white border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30 font-mono"
                    />
                  </div>
                  {errors.renterPhone && (
                    <p className="text-[11px] text-red-600 mt-1">{errors.renterPhone}</p>
                  )}
                </div>

                <div>
                  <label className="block font-semibold text-stone-800 mb-1">
                    Business / Contractor Name <span className="text-stone-400 font-normal">(Optional)</span>
                  </label>
                  <div className="relative">
                    <Briefcase className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={renterBusiness}
                      onChange={(e) => setRenterBusiness(e.target.value)}
                      placeholder="e.g. SK Builders & Interiors"
                      className="w-full pl-9 pr-3 py-2 bg-white border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-800 mb-1">
                  Project Location & Intended Use <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <FileText className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                  <textarea
                    rows={3}
                    value={projectNote}
                    onChange={(e) => setProjectNote(e.target.value)}
                    placeholder="Briefly describe where the machine will be deployed and your transport plan (e.g. Concrete slab pour at Rajajinagar site, will arrange Tata Ace for pickup at 8 AM)..."
                    className="w-full pl-9 pr-3 py-2 bg-white border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30"
                  />
                </div>
                {errors.projectNote && (
                  <p className="text-[11px] text-red-600 mt-1">{errors.projectNote}</p>
                )}
              </div>
            </div>

            {/* Prototype terms notice */}
            <div className="text-[11px] text-stone-500 bg-stone-50 p-3 rounded-lg border border-stone-200">
              <strong>Transparent Workflow: </strong>
              Udaya does not take money upfront. Your booking request will be shared with the owner to confirm availability. Physical handover and refundable deposit are handled directly upon machine inspection.
            </div>

            {/* Submit Action */}
            <div className="pt-2 flex items-center justify-end gap-3 border-t border-stone-200">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-xs font-bold text-white bg-emerald-900 hover:bg-emerald-950 rounded-lg transition-all shadow-sm active:scale-[0.98] cursor-pointer"
              >
                Send Booking Request
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
