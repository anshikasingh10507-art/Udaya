import React, { useState } from 'react';
import { EquipmentItem, BookingRequest, BookingStatus } from '../types';
import {
  CheckCircle,
  XCircle,
  Clock,
  Phone,
  User,
  Calendar,
  IndianRupee,
  PlusCircle,
  RefreshCw,
  Sparkles,
  Building2,
  Check,
  X,
  AlertCircle,
  MapPin,
} from 'lucide-react';

interface OwnerDashboardProps {
  equipmentList: EquipmentItem[];
  bookingRequests: BookingRequest[];
  onUpdateRequestStatus: (requestId: string, newStatus: BookingStatus, note?: string) => void;
  onToggleEquipmentAvailability: (equipmentId: string) => void;
  onOpenListModal: () => void;
  onSeedSampleRequest: () => void;
  onResetDemoData: () => void;
  onViewItemInCatalog: (item: EquipmentItem) => void;
}

export const OwnerDashboard: React.FC<OwnerDashboardProps> = ({
  equipmentList,
  bookingRequests,
  onUpdateRequestStatus,
  onToggleEquipmentAvailability,
  onOpenListModal,
  onSeedSampleRequest,
  onResetDemoData,
  onViewItemInCatalog,
}) => {
  const [activeTab, setActiveTab] = useState<'requests' | 'equipment'>('requests');
  const [requestFilter, setRequestFilter] = useState<'all' | 'pending' | 'accepted' | 'declined'>('all');
  const [activeActionModal, setActiveActionModal] = useState<{
    request: BookingRequest;
    type: 'accept' | 'decline';
  } | null>(null);
  const [responseNote, setResponseNote] = useState('');

  // Counts
  const pendingCount = bookingRequests.filter((r) => r.status === 'pending').length;
  const acceptedCount = bookingRequests.filter((r) => r.status === 'accepted').length;
  const declinedCount = bookingRequests.filter((r) => r.status === 'declined').length;

  const totalEstimatedEarnings = bookingRequests
    .filter((r) => r.status === 'accepted')
    .reduce((sum, r) => sum + r.estimatedRentalTotal, 0);

  // Filtered requests
  const filteredRequests = bookingRequests.filter((r) => {
    if (requestFilter === 'all') return true;
    return r.status === requestFilter;
  });

  const handleConfirmAction = () => {
    if (!activeActionModal) return;
    onUpdateRequestStatus(
      activeActionModal.request.id,
      activeActionModal.type === 'accept' ? 'accepted' : 'declined',
      responseNote.trim() || undefined
    );
    setActiveActionModal(null);
    setResponseNote('');
  };

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Dashboard Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-stone-200">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-950 uppercase tracking-wider mb-1">
            <Building2 className="w-3.5 h-3.5 text-emerald-900" />
            Equipment Owner Workspace
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900">
            Owner Hub & Request Manager
          </h2>
          <p className="text-xs sm:text-sm text-stone-600 mt-0.5">
            Manage your idle equipment listings, review incoming rental inquiries, and approve handovers.
          </p>
        </div>

        {/* Pitch Tools & Listing CTA */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={onSeedSampleRequest}
            className="px-3 py-2 text-xs font-semibold text-stone-700 bg-white hover:bg-stone-50 border border-stone-300 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Simulate an incoming booking request from a local contractor"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Simulate Incoming Request</span>
          </button>

          <button
            onClick={onOpenListModal}
            className="px-4 py-2 text-xs font-bold text-white bg-emerald-900 hover:bg-emerald-950 rounded-lg shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5 text-amber-400" />
            <span>List New Equipment</span>
          </button>
        </div>
      </div>

      {/* KPI Overview Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-xl border border-stone-200 shadow-2xs">
          <span className="text-xs text-stone-500 font-medium block">Action Needed</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-extrabold text-amber-600 tabular-nums">
              {pendingCount}
            </span>
            <span className="text-xs text-stone-500">pending inquiries</span>
          </div>
          <div className="text-[11px] text-stone-400 mt-1">Requires owner review</div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200 shadow-2xs">
          <span className="text-xs text-stone-500 font-medium block">Approved Bookings</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-extrabold text-emerald-800 tabular-nums">
              {acceptedCount}
            </span>
            <span className="text-xs text-stone-500">confirmed jobs</span>
          </div>
          <div className="text-[11px] text-stone-400 mt-1">Ready for handover</div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200 shadow-2xs">
          <span className="text-xs text-stone-500 font-medium block">Estimated Revenue</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-extrabold text-stone-900 tabular-nums">
              ₹{totalEstimatedEarnings.toLocaleString('en-IN')}
            </span>
          </div>
          <div className="text-[11px] text-stone-400 mt-1">From approved rentals</div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200 shadow-2xs">
          <span className="text-xs text-stone-500 font-medium block">Active Machines</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-extrabold text-stone-900 tabular-nums">
              {equipmentList.length}
            </span>
            <span className="text-xs text-stone-500">
              ({equipmentList.filter((e) => e.isAvailable).length} available)
            </span>
          </div>
          <div className="text-[11px] text-stone-400 mt-1">Listed in Peenya cluster</div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center justify-between border-b border-stone-200 pt-2">
        <div className="flex items-center gap-6 text-sm font-semibold">
          <button
            onClick={() => setActiveTab('requests')}
            className={`pb-3 relative cursor-pointer ${
              activeTab === 'requests'
                ? 'text-emerald-950 border-b-2 border-emerald-900'
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            Incoming Booking Requests
            {pendingCount > 0 && (
              <span className="ml-2 px-1.5 py-0.5 text-xs bg-amber-100 text-amber-900 rounded font-bold">
                {pendingCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('equipment')}
            className={`pb-3 relative cursor-pointer ${
              activeTab === 'equipment'
                ? 'text-emerald-950 border-b-2 border-emerald-900'
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            My Listed Equipment ({equipmentList.length})
          </button>
        </div>

        {activeTab === 'requests' && (
          <div className="hidden sm:flex items-center gap-1.5 text-xs">
            {(['all', 'pending', 'accepted', 'declined'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setRequestFilter(filter)}
                className={`px-2.5 py-1 rounded-md capitalize cursor-pointer transition-colors ${
                  requestFilter === filter
                    ? 'bg-stone-900 text-white font-semibold'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Tab 1: Booking Requests List */}
      {activeTab === 'requests' && (
        <div className="space-y-4">
          {filteredRequests.length > 0 ? (
            <div className="space-y-4">
              {filteredRequests.map((req) => (
                <div
                  key={req.id}
                  className="bg-white rounded-xl border border-stone-200/90 shadow-2xs hover:shadow-xs transition-shadow p-5 sm:p-6"
                >
                  <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-5">
                    {/* Left: Machine & Renter Snapshot */}
                    <div className="flex items-start gap-4 flex-1">
                      <img
                        src={req.equipmentImageUrl}
                        alt={req.equipmentTitle}
                        className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-lg border border-stone-200 shrink-0"
                      />

                      <div className="space-y-1.5 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-semibold text-emerald-950">
                            {req.equipmentTitle}
                          </span>
                          <span className="text-stone-300">·</span>
                          <span className="text-xs text-stone-500">Ref #{req.id}</span>
                          <span className="text-stone-300">·</span>
                          <span className="text-xs text-stone-400">
                            {new Date(req.createdAt).toLocaleDateString('en-IN', {
                              day: 'numeric',
                              month: 'short',
                            })}
                          </span>
                        </div>

                        {/* Renter Details */}
                        <div className="text-xs text-stone-700 flex flex-wrap items-center gap-x-3 gap-y-1">
                          <span className="font-bold text-stone-900 flex items-center gap-1">
                            <User className="w-3.5 h-3.5 text-stone-400" />
                            {req.renterName}
                          </span>
                          <span className="text-stone-500">
                            ({req.renterBusiness})
                          </span>
                          <span className="font-mono text-stone-600 flex items-center gap-1">
                            <Phone className="w-3.5 h-3.5 text-stone-400" />
                            {req.renterPhone}
                          </span>
                        </div>

                        {/* Project Purpose Note */}
                        <div className="text-xs text-stone-600 bg-stone-50 p-2.5 rounded-lg border border-stone-200/70 mt-2">
                          <span className="font-semibold text-stone-800">Renter's Project: </span>
                          {req.projectNote}
                        </div>

                        {req.responseNote && (
                          <div className="text-xs text-emerald-950 bg-emerald-50/80 p-2.5 rounded-lg border border-emerald-200 mt-2">
                            <span className="font-semibold">Owner Response Note: </span>
                            {req.responseNote}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Middle: Rental Numbers */}
                    <div className="lg:border-l lg:border-stone-200 lg:pl-6 text-xs space-y-1 shrink-0 min-w-44">
                      <div className="text-stone-500">Requested Window:</div>
                      <div className="font-semibold text-stone-800 flex items-center gap-1 text-xs">
                        <Calendar className="w-3.5 h-3.5 text-stone-400" />
                        {req.startDate} ({req.durationDays} {req.durationDays === 1 ? 'day' : 'days'})
                      </div>

                      <div className="pt-2 text-stone-500">Rental Value:</div>
                      <div className="text-base font-extrabold text-stone-900 tabular-nums">
                        ₹{req.estimatedRentalTotal.toLocaleString('en-IN')}
                      </div>
                      <div className="text-[11px] text-stone-400">
                        + ₹{req.securityDeposit.toLocaleString('en-IN')} refundable deposit
                      </div>
                    </div>

                    {/* Right: Status and Actions */}
                    <div className="flex flex-col items-start lg:items-end justify-between gap-3 shrink-0">
                      <div>
                        {req.status === 'pending' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold bg-amber-100 text-amber-900 rounded-md">
                            <Clock className="w-3 h-3" />
                            Awaiting Review
                          </span>
                        )}
                        {req.status === 'accepted' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold bg-emerald-100 text-emerald-900 rounded-md">
                            <Check className="w-3.5 h-3.5" />
                            Approved · Ready
                          </span>
                        )}
                        {req.status === 'declined' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold bg-stone-100 text-stone-600 rounded-md">
                            <X className="w-3.5 h-3.5" />
                            Declined
                          </span>
                        )}
                      </div>

                      {req.status === 'pending' ? (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() =>
                              setActiveActionModal({ request: req, type: 'decline' })
                            }
                            className="px-3 py-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 hover:bg-stone-100 border border-stone-200 rounded-lg transition-colors cursor-pointer"
                          >
                            Decline
                          </button>
                          <button
                            onClick={() =>
                              setActiveActionModal({ request: req, type: 'accept' })
                            }
                            className="px-4 py-1.5 text-xs font-bold text-white bg-emerald-900 hover:bg-emerald-950 rounded-lg shadow-2xs transition-colors cursor-pointer"
                          >
                            Accept Request
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() =>
                            onUpdateRequestStatus(
                              req.id,
                              req.status === 'accepted' ? 'declined' : 'accepted'
                            )
                          }
                          className="text-[11px] text-stone-500 hover:text-stone-800 underline cursor-pointer"
                        >
                          Change status to {req.status === 'accepted' ? 'Declined' : 'Approved'}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-xl border border-stone-200 p-4">
              <Clock className="w-10 h-10 text-stone-300 mx-auto mb-2" />
              <h4 className="text-sm font-bold text-stone-800">
                No {requestFilter !== 'all' ? requestFilter : ''} booking requests found
              </h4>
              <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
                Click "Simulate Incoming Request" above to test the owner review and approval journey!
              </p>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Equipment Inventory & Availability Toggles */}
      {activeTab === 'equipment' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {equipmentList.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-2xs flex flex-col"
            >
              <div className="relative aspect-video bg-stone-100">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3">
                  <span
                    className={`text-[11px] font-semibold px-2 py-0.5 rounded shadow-2xs ${
                      item.isAvailable
                        ? 'bg-emerald-900/90 text-white'
                        : 'bg-stone-800/90 text-stone-200'
                    }`}
                  >
                    {item.isAvailable ? 'Available for Rent' : 'In Use / Booked'}
                  </span>
                </div>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <div className="text-[11px] text-stone-500">{item.categoryLabel}</div>
                  <h4 className="text-sm font-bold text-stone-900 mt-0.5 leading-snug">
                    {item.title}
                  </h4>
                  <div className="flex items-center gap-1 text-xs text-stone-500 mt-1">
                    <MapPin className="w-3 h-3 text-stone-400" />
                    {item.location}
                  </div>
                </div>

                <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
                  <div>
                    <span className="text-base font-extrabold text-stone-900 tabular-nums">
                      ₹{item.dailyRate.toLocaleString('en-IN')}
                    </span>
                    <span className="text-xs text-stone-500"> / day</span>
                  </div>

                  {/* Availability Toggle */}
                  <button
                    onClick={() => onToggleEquipmentAvailability(item.id)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                      item.isAvailable
                        ? 'bg-stone-100 hover:bg-stone-200 text-stone-700 border-stone-300'
                        : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-300'
                    }`}
                  >
                    Mark as {item.isAvailable ? 'Booked' : 'Available'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Response Note Modal (Accept / Decline Confirmation) */}
      {activeActionModal && (
        <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-base font-bold text-stone-900">
                {activeActionModal.type === 'accept'
                  ? 'Accept Booking Request'
                  : 'Decline Booking Request'}
              </h4>
              <button
                onClick={() => setActiveActionModal(null)}
                className="text-stone-400 hover:text-stone-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-stone-600">
              {activeActionModal.type === 'accept'
                ? `You are confirming availability for ${activeActionModal.request.renterName} (${activeActionModal.request.equipmentTitle}) for ${activeActionModal.request.durationDays} days.`
                : `You are declining this request. The renter will be notified.`}
            </p>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Optional Message / Handover Notes for Renter:
              </label>
              <textarea
                rows={3}
                value={responseNote}
                onChange={(e) => setResponseNote(e.target.value)}
                placeholder={
                  activeActionModal.type === 'accept'
                    ? 'e.g. Approved. Please bring GST copy or Aadhaar ID when picking up from our Peenya shop.'
                    : 'e.g. Sorry, the equipment is undergoing scheduled maintenance on these dates.'
                }
                className="w-full p-2.5 text-xs border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-900/30"
              />
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                onClick={() => setActiveActionModal(null)}
                className="px-3 py-2 text-xs font-semibold text-stone-600 hover:text-stone-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmAction}
                className={`px-4 py-2 text-xs font-bold text-white rounded-lg transition-colors cursor-pointer ${
                  activeActionModal.type === 'accept'
                    ? 'bg-emerald-900 hover:bg-emerald-950'
                    : 'bg-stone-800 hover:bg-stone-900'
                }`}
              >
                {activeActionModal.type === 'accept' ? 'Confirm Acceptance' : 'Confirm Decline'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Demo Reset Helper in Footer */}
      <div className="p-4 bg-stone-100/70 rounded-xl border border-stone-200/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-stone-500">
        <div>
          <strong>Pitch Demo Reset: </strong>
          Need to present from scratch to judges? You can restore the initial 9 equipment listings and starter requests anytime.
        </div>
        <button
          onClick={onResetDemoData}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-stone-300 hover:bg-stone-50 rounded-lg text-stone-700 font-semibold cursor-pointer shrink-0 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reset Sample Demo Data</span>
        </button>
      </div>
    </div>
  );
};
