import React from 'react';
import {
  Search,
  CalendarCheck,
  Truck,
  PlusCircle,
  CheckCircle2,
  Coins,
  ShieldAlert,
  FileCheck2,
  HardHat,
  ArrowRight,
} from 'lucide-react';

interface HowItWorksSectionProps {
  onExplore: () => void;
  onListEquipment: () => void;
}

export const HowItWorksSection: React.FC<HowItWorksSectionProps> = ({
  onExplore,
  onListEquipment,
}) => {
  return (
    <section className="py-14 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
      {/* Intro Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-emerald-900 bg-emerald-50 px-3 py-1 rounded-md border border-emerald-900/10 inline-block">
          Marketplace Mechanics
        </span>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-stone-900 tracking-tight">
          How Udaya Works
        </h2>
        <p className="text-sm sm:text-base text-stone-600 leading-relaxed">
          The central idea is simple: turn idle equipment into earning assets by making local equipment rental easier to discover and arrange.
        </p>
      </div>

      {/* 2-Column Process: Renters vs Owners */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* Renter Journey */}
        <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-6 shadow-2xs">
          <div className="flex items-center gap-3 pb-4 border-b border-stone-100">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-900 flex items-center justify-center font-bold">
              01
            </div>
            <div>
              <h3 className="text-lg font-bold text-stone-900">For Renters & Contractors</h3>
              <p className="text-xs text-stone-500">Rent what you need, only when you need it</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center text-stone-700 shrink-0 font-semibold text-xs">
                1
              </div>
              <div>
                <h4 className="text-sm font-bold text-stone-900">Discover Local Equipment</h4>
                <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                  Browse by category (concrete mixers, silent generators, power tillers, core drills) and filter by your local industrial area.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center text-stone-700 shrink-0 font-semibold text-xs">
                2
              </div>
              <div>
                <h4 className="text-sm font-bold text-stone-900">Check Transparent Pricing</h4>
                <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                  See exact daily rates in rupees, refundable security deposits, and optional operator support. No hidden middleman commissions.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center text-stone-700 shrink-0 font-semibold text-xs">
                3
              </div>
              <div>
                <h4 className="text-sm font-bold text-stone-900">Submit Booking Request & Pick Up</h4>
                <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                  Send your project requirements to the owner. Once approved, arrange direct pickup from their shop or yard.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={onExplore}
              className="w-full py-2.5 px-4 text-xs font-semibold text-emerald-950 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>Browse Catalog as Renter</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Owner Journey */}
        <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-6 shadow-2xs">
          <div className="flex items-center gap-3 pb-4 border-b border-stone-100">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-900 flex items-center justify-center font-bold">
              02
            </div>
            <div>
              <h3 className="text-lg font-bold text-stone-900">For Equipment Owners</h3>
              <p className="text-xs text-stone-500">Monetize idle machinery between your own projects</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center text-stone-700 shrink-0 font-semibold text-xs">
                1
              </div>
              <div>
                <h4 className="text-sm font-bold text-stone-900">List Your Equipment Free</h4>
                <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                  Create a listing with machine photos, daily rate in rupees, refundable security deposit, and pickup address in under 2 minutes.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center text-stone-700 shrink-0 font-semibold text-xs">
                2
              </div>
              <div>
                <h4 className="text-sm font-bold text-stone-900">Review Direct Booking Inquiries</h4>
                <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                  Receive inquiries from local contractors. Review their project notes, contact details, and dates before choosing to accept or decline.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center text-stone-700 shrink-0 font-semibold text-xs">
                3
              </div>
              <div>
                <h4 className="text-sm font-bold text-stone-900">Coordinate Handover & Earn</h4>
                <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                  Collect the refundable deposit at your shop floor, perform physical handover check, and get paid for idle days.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={onListEquipment}
              className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-emerald-900 hover:bg-emerald-950 rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>List Your Equipment Free</span>
              <PlusCircle className="w-3.5 h-3.5 text-amber-400" />
            </button>
          </div>
        </div>
      </div>

      {/* Trust & Safety Section (Honest Pitch Disclosure) */}
      <div className="bg-stone-100/80 rounded-2xl border border-stone-300/80 p-6 sm:p-8 space-y-5">
        <div className="flex items-center gap-2 text-stone-900">
          <ShieldAlert className="w-5 h-5 text-amber-700 shrink-0" />
          <h3 className="text-base font-bold">
            Trust, Safety & Founder Disclosure (Startup Pitch Note)
          </h3>
        </div>

        <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
          Because industrial and agricultural machinery represents significant capital, Udaya does <strong>not</strong> make false claims that users, equipment, or transactions are pre-underwritten or fully insured in this early prototype.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 text-xs">
          <div className="p-4 bg-white rounded-xl border border-stone-200">
            <div className="font-bold text-stone-900 mb-1">Current Prototype Scope</div>
            <p className="text-stone-600 leading-normal">
              Focuses on peer-to-peer discovery, transparent rupee pricing, duration calculation, and owner booking request management.
            </p>
          </div>

          <div className="p-4 bg-white rounded-xl border border-stone-200">
            <div className="font-bold text-stone-900 mb-1">Pre-Launch Pilot Plan</div>
            <p className="text-stone-600 leading-normal">
              Introducing business KYC (GSTIN & Aadhaar verification), standardized physical handover checklists, and escrow deposit security.
            </p>
          </div>

          <div className="p-4 bg-white rounded-xl border border-stone-200">
            <div className="font-bold text-stone-900 mb-1">Zero Hidden Markups</div>
            <p className="text-stone-600 leading-normal">
              No middleman brokers taking 30% cuts. Transparent peer pricing directly negotiated and approved by local small businesses.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
