import React, { useState } from 'react';
import { Compass, Check, ChevronUp, ChevronDown, Sparkles, Building2, Eye } from 'lucide-react';

interface PitchWalkthroughRibbonProps {
  currentTab: 'marketplace' | 'owner-hub' | 'how-it-works';
  onSelectTab: (tab: 'marketplace' | 'owner-hub' | 'how-it-works') => void;
  onOpenListModal: () => void;
  pendingCount: number;
}

export const PitchWalkthroughRibbon: React.FC<PitchWalkthroughRibbonProps> = ({
  currentTab,
  onSelectTab,
  onOpenListModal,
  pendingCount,
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(true);

  return (
    <aside
      aria-label="Judge Demo Walkthrough"
      className="fixed bottom-3 right-3 sm:bottom-4 sm:right-4 z-40 max-w-sm sm:max-w-md w-[calc(100vw-24px)] transition-all duration-200"
    >
      <div className="bg-stone-900 text-stone-100 rounded-xl shadow-2xl border border-stone-700/80 overflow-hidden text-xs">
        {/* Toggle Bar */}
        <div
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center justify-between px-3.5 py-2.5 bg-stone-800/90 cursor-pointer select-none hover:bg-stone-800 transition-colors"
        >
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400"></span>
            <span className="font-bold text-stone-100 text-xs tracking-wide">
              Pitch Demo Quick Guide (2-Min Demo)
            </span>
          </div>

          <button
            type="button"
            className="text-stone-400 hover:text-white p-0.5 cursor-pointer"
            aria-label={isExpanded ? 'Collapse guide' : 'Expand guide'}
          >
            {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        </div>

        {/* Content Body */}
        {isExpanded && (
          <div className="p-3.5 space-y-3 bg-stone-900/95">
            <p className="text-[11px] text-stone-400 leading-normal">
              Test the end-to-end user journey as both a <strong>Renter</strong> and an <strong>Equipment Owner</strong>:
            </p>

            <div className="space-y-2 text-stone-300 text-[11px]">
              <div
                onClick={() => onSelectTab('marketplace')}
                className={`p-2 rounded-lg border transition-colors cursor-pointer flex items-center justify-between ${
                  currentTab === 'marketplace'
                    ? 'bg-emerald-950/70 border-emerald-700 text-emerald-200'
                    : 'bg-stone-800/60 border-stone-700/60 hover:bg-stone-800 text-stone-300'
                }`}
              >
                <span>
                  <strong>Step 1:</strong> Search & Filter equipment in Bengaluru
                </span>
                <span className="text-[10px] text-stone-400">View Catalog →</span>
              </div>

              <div className="p-2 rounded-lg bg-stone-800/60 border border-stone-700/60 text-stone-300">
                <span>
                  <strong>Step 2:</strong> Click any machine to open the live price calculator and submit a booking request.
                </span>
              </div>

              <div
                onClick={() => onSelectTab('owner-hub')}
                className={`p-2 rounded-lg border transition-colors cursor-pointer flex items-center justify-between ${
                  currentTab === 'owner-hub'
                    ? 'bg-emerald-950/70 border-emerald-700 text-emerald-200'
                    : 'bg-stone-800/60 border-stone-700/60 hover:bg-stone-800 text-stone-300'
                }`}
              >
                <span>
                  <strong>Step 3:</strong> Switch to <strong>Owner Hub</strong> to Accept or Decline requests
                  {pendingCount > 0 && ` (${pendingCount} pending)`}
                </span>
                <span className="text-[10px] text-amber-400 font-semibold">Open Hub →</span>
              </div>

              <div
                onClick={onOpenListModal}
                className="p-2 rounded-lg bg-stone-800/60 border border-stone-700/60 hover:bg-stone-800 text-stone-300 transition-colors cursor-pointer flex items-center justify-between"
              >
                <span>
                  <strong>Step 4:</strong> Try <strong>"List Equipment"</strong> to add an idle machine in real-time
                </span>
                <span className="text-[10px] text-emerald-400 font-semibold">+ List Now</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
