import React from 'react';
import { ShieldCheck, HardHat, PlusCircle, Compass } from 'lucide-react';

interface NavbarProps {
  currentTab: 'marketplace' | 'owner-hub' | 'how-it-works';
  onSelectTab: (tab: 'marketplace' | 'owner-hub' | 'how-it-works') => void;
  pendingRequestsCount: number;
  onOpenListModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  pendingRequestsCount,
  onOpenListModal,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-stone-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-18">
          {/* Zone 1: Single text element wordmark */}
          <button
            onClick={() => onSelectTab('marketplace')}
            className="flex items-center gap-2.5 text-left group focus:outline-none"
          >
            <div className="w-9 h-9 rounded-lg bg-emerald-900 flex items-center justify-center text-amber-400 font-bold text-lg shadow-sm">
              U
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-stone-900 whitespace-nowrap block">
                Udaya
              </span>
              <span className="text-[11px] font-medium text-stone-500 uppercase tracking-wider block -mt-1">
                Equipment Marketplace
              </span>
            </div>
          </button>

          {/* Zone 2: 4 clean single-line text navigation links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-stone-600">
            <button
              onClick={() => onSelectTab('marketplace')}
              className={`hover:text-emerald-900 transition-colors whitespace-nowrap cursor-pointer py-1 ${
                currentTab === 'marketplace'
                  ? 'text-emerald-950 font-semibold border-b-2 border-emerald-900'
                  : ''
              }`}
            >
              Explore Equipment
            </button>
            <button
              onClick={() => onSelectTab('owner-hub')}
              className={`hover:text-emerald-900 transition-colors whitespace-nowrap cursor-pointer py-1 relative ${
                currentTab === 'owner-hub'
                  ? 'text-emerald-950 font-semibold border-b-2 border-emerald-900'
                  : ''
              }`}
            >
              Owner Hub
              {pendingRequestsCount > 0 && (
                <span className="ml-1.5 px-1.5 py-0.5 text-[10px] font-bold bg-amber-100 text-amber-900 rounded-sm">
                  {pendingRequestsCount} new
                </span>
              )}
            </button>
            <button
              onClick={() => onSelectTab('how-it-works')}
              className={`hover:text-emerald-900 transition-colors whitespace-nowrap cursor-pointer py-1 ${
                currentTab === 'how-it-works'
                  ? 'text-emerald-950 font-semibold border-b-2 border-emerald-900'
                  : ''
              }`}
            >
              How It Works & Safety
            </button>
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenListModal}
              className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-emerald-900 hover:bg-emerald-950 rounded-lg shadow-sm transition-all whitespace-nowrap active:scale-[0.98] cursor-pointer"
            >
              <PlusCircle className="w-4 h-4 text-amber-400" />
              <span>List Your Equipment</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
