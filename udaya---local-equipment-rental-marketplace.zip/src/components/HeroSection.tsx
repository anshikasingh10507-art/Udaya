import React from 'react';
import { ArrowRight, Wrench, Coins, Clock, MapPin, CheckCircle2 } from 'lucide-react';

interface HeroSectionProps {
  onExplore: () => void;
  onListEquipment: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExplore,
  onListEquipment,
}) => {
  return (
    <section className="relative overflow-hidden pt-8 pb-14 border-b border-stone-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Core Value Proposition */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wide uppercase text-emerald-900 bg-emerald-50/80 px-3 py-1.5 rounded-md border border-emerald-900/10">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
              Local Equipment-Rental Marketplace · Bengaluru Hub Pilot
            </div>

            <div className="space-y-3">
              <h1 className="text-4xl sm:text-5xl lg:text-5xl font-extrabold tracking-tight text-stone-900 leading-[1.15] text-balance">
                No favors. No middlemen. <br />
                <span className="text-emerald-900">Just Udaya.</span>
              </h1>
              <p className="text-lg text-stone-700 leading-relaxed max-w-2xl text-balance">
                Turn idle machinery into earning assets. Udaya connects local small businesses, workshops, and contractors to rent available equipment with transparent daily rates and direct peer coordination.
              </p>
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onExplore}
                className="px-6 py-3.5 text-sm font-semibold text-white bg-emerald-900 hover:bg-emerald-950 rounded-lg shadow-sm hover:shadow transition-all flex items-center gap-2 active:scale-[0.98] cursor-pointer"
              >
                <span>Explore Available Equipment</span>
                <ArrowRight className="w-4 h-4 text-amber-400" />
              </button>
              <button
                onClick={onListEquipment}
                className="px-6 py-3.5 text-sm font-semibold text-stone-800 bg-white hover:bg-stone-50 border border-stone-300 rounded-lg shadow-2xs transition-all active:scale-[0.98] cursor-pointer"
              >
                List Your Idle Equipment
              </button>
            </div>

            {/* 2-Sided Marketplace Value Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-stone-200">
              <div className="bg-stone-50/70 p-4 rounded-lg border border-stone-200/70">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-900 block mb-1">
                  For Equipment Owners
                </span>
                <p className="text-xs text-stone-600 leading-normal">
                  Put idle mixers, welders, and tillers to work between jobs. Zero listing fees during launch; review and approve every booking request yourself.
                </p>
              </div>

              <div className="bg-stone-50/70 p-4 rounded-lg border border-stone-200/70">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-900 block mb-1">
                  For Renters & Contractors
                </span>
                <p className="text-xs text-stone-600 leading-normal">
                  Find available tools nearby without calling 10 middleman brokers. See transparent daily rates and clear deposits upfront with zero hidden fees.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Yard */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-stone-300 shadow-md bg-stone-100 group">
              <img
                src="/src/assets/images/hero_equipment_yard_1794025851706.jpg"
                alt="Local equipment rental yard with machinery in Peenya industrial cluster"
                className="w-full h-80 sm:h-96 object-cover transition-transform duration-500 group-hover:scale-102"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-950/20 to-transparent"></div>
              
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <div className="text-xs font-medium text-stone-300 flex items-center gap-1.5 mb-1">
                  <MapPin className="w-3.5 h-3.5 text-amber-400" />
                  Peenya & Yeshwanthpur Industrial Belt · Bengaluru
                </div>
                <div className="text-sm font-semibold text-white">
                  Local peer-to-peer equipment hub
                </div>
                <div className="text-xs text-stone-300 mt-0.5">
                  Small workshops sharing mixers, gensets, welders, and farming tools.
                </div>
              </div>
            </div>

            {/* Quick Trust Stat Ribbon */}
            <div className="mt-3 flex items-center justify-between text-xs text-stone-500 px-2">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                100% Free Owner Listings
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                Clear Rupee Pricing
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                Direct Owner Handover
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
