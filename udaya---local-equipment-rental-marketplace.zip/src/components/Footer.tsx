import React from 'react';

interface FooterProps {
  onSelectTab: (tab: 'marketplace' | 'owner-hub' | 'how-it-works') => void;
  onOpenListModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectTab, onOpenListModal }) => {
  return (
    <footer className="bg-stone-900 text-stone-300 border-t border-stone-800 pt-12 pb-16 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-stone-800">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded bg-emerald-800 flex items-center justify-center text-amber-400 font-bold text-sm">
                U
              </div>
              <span className="text-xl font-bold tracking-tight text-white">Udaya</span>
            </div>
            <p className="text-xs text-stone-400 font-medium">
              No favors. No middlemen. Just Udaya.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-stone-400">
            <button
              onClick={() => onSelectTab('marketplace')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Explore Equipment
            </button>
            <button
              onClick={() => onSelectTab('owner-hub')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Owner Hub
            </button>
            <button
              onClick={() => onSelectTab('how-it-works')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              How It Works & Safety
            </button>
            <button
              onClick={onOpenListModal}
              className="text-amber-400 hover:text-amber-300 font-semibold transition-colors cursor-pointer"
            >
              List Equipment
            </button>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-stone-500">
          <p>
            © {new Date().getFullYear()} Udaya Equipment Technologies. Built for startup competition validation.
          </p>
          <p className="text-stone-400">
            Initial pilot focused on Peenya, Yeshwanthpur & Bengaluru industrial clusters.
          </p>
        </div>
      </div>
    </footer>
  );
};
