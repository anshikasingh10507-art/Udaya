export type EquipmentCategory = 'all' | 'construction' | 'agricultural' | 'tools' | 'commercial';

export interface EquipmentItem {
  id: string;
  title: string;
  category: 'construction' | 'agricultural' | 'tools' | 'commercial';
  categoryLabel: string;
  tagline: string;
  description: string;
  specifications: string[];
  dailyRate: number; // in INR
  securityDeposit: number; // in INR
  billingUnit: 'per day' | 'per shift (8 hrs)';
  location: string;
  subLocation: string; // e.g. "Peenya Industrial Area, Stage 2"
  ownerName: string;
  ownerBusiness: string;
  ownerContact: string;
  isAvailable: boolean;
  availabilitySchedule: string;
  condition: string;
  imageUrl: string;
  pickupTerms: string;
  operatorProvided: boolean;
  operatorNote?: string;
  isFeatured?: boolean;
}

export type BookingStatus = 'pending' | 'accepted' | 'declined';

export interface BookingRequest {
  id: string;
  equipmentId: string;
  equipmentTitle: string;
  equipmentImageUrl: string;
  ownerBusiness: string;
  renterName: string;
  renterPhone: string;
  renterBusiness: string;
  startDate: string;
  durationDays: number;
  dailyRate: number;
  estimatedRentalTotal: number;
  securityDeposit: number;
  estimatedGrandTotal: number;
  projectNote: string;
  status: BookingStatus;
  createdAt: string;
  responseNote?: string;
}

export interface NewListingFormData {
  title: string;
  category: 'construction' | 'agricultural' | 'tools' | 'commercial';
  description: string;
  specifications: string;
  dailyRate: number;
  securityDeposit: number;
  location: string;
  subLocation: string;
  ownerBusiness: string;
  ownerContact: string;
  condition: string;
  pickupTerms: string;
  imageUrl: string;
  operatorProvided: boolean;
}
