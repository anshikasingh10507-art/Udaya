import React, { useState, useEffect } from 'react';
import { EquipmentItem, BookingRequest, BookingStatus } from './types';
import { INITIAL_EQUIPMENT_LIST, INITIAL_BOOKING_REQUESTS } from './data/initialData';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { MarketplaceGrid } from './components/MarketplaceGrid';
import { EquipmentDetailModal } from './components/EquipmentDetailModal';
import { BookingRequestModal } from './components/BookingRequestModal';
import { OwnerDashboard } from './components/OwnerDashboard';
import { ListEquipmentModal } from './components/ListEquipmentModal';
import { HowItWorksSection } from './components/HowItWorksSection';
import { PitchWalkthroughRibbon } from './components/PitchWalkthroughRibbon';
import { Footer } from './components/Footer';

const STORAGE_EQUIPMENT_KEY = 'udaya_equipment_catalog_v1';
const STORAGE_REQUESTS_KEY = 'udaya_booking_requests_v1';

export default function App() {
  // Initialize equipment from localStorage or defaults
  const [equipmentList, setEquipmentList] = useState<EquipmentItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_EQUIPMENT_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to load saved equipment', e);
    }
    return INITIAL_EQUIPMENT_LIST;
  });

  // Initialize booking requests from localStorage or defaults
  const [bookingRequests, setBookingRequests] = useState<BookingRequest[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_REQUESTS_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to load saved requests', e);
    }
    return INITIAL_BOOKING_REQUESTS;
  });

  // Navigation tab: 'marketplace' | 'owner-hub' | 'how-it-works'
  const [currentTab, setCurrentTab] = useState<'marketplace' | 'owner-hub' | 'how-it-works'>('marketplace');

  // Modals state
  const [detailItem, setDetailItem] = useState<EquipmentItem | null>(null);
  const [bookingFlowItem, setBookingFlowItem] = useState<{
    item: EquipmentItem;
    initialDays: number;
    startDate: string;
    includeOperator: boolean;
  } | null>(null);
  const [isListModalOpen, setIsListModalOpen] = useState(false);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_EQUIPMENT_KEY, JSON.stringify(equipmentList));
    } catch (e) {
      console.warn('Could not save equipment', e);
    }
  }, [equipmentList]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_REQUESTS_KEY, JSON.stringify(bookingRequests));
    } catch (e) {
      console.warn('Could not save requests', e);
    }
  }, [bookingRequests]);

  // Handlers
  const handleSelectItemForDetail = (item: EquipmentItem) => {
    setDetailItem(item);
  };

  const handleStartBookingFromCard = (item: EquipmentItem) => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    setBookingFlowItem({
      item,
      initialDays: 2,
      startDate: tomorrow.toISOString().split('T')[0],
      includeOperator: false,
    });
  };

  const handleStartBookingFromDetail = (
    item: EquipmentItem,
    initialDays: number,
    startDate: string,
    includeOperator: boolean
  ) => {
    setDetailItem(null);
    setBookingFlowItem({
      item,
      initialDays,
      startDate,
      includeOperator,
    });
  };

  const handleSubmitBooking = (
    data: Omit<BookingRequest, 'id' | 'createdAt' | 'status'>
  ): string => {
    const newId = `UDY-${Math.floor(1000 + Math.random() * 9000)}`;
    const newRequest: BookingRequest = {
      ...data,
      id: newId,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    setBookingRequests((prev) => [newRequest, ...prev]);
    return newId;
  };

  const handleAddEquipment = (newItemData: Omit<EquipmentItem, 'id'>): string => {
    const newId = `eq-${String(equipmentList.length + 1).padStart(3, '0')}`;
    const newItem: EquipmentItem = {
      ...newItemData,
      id: newId,
    };
    setEquipmentList((prev) => [newItem, ...prev]);
    return newId;
  };

  const handleUpdateRequestStatus = (
    requestId: string,
    newStatus: BookingStatus,
    note?: string
  ) => {
    setBookingRequests((prev) =>
      prev.map((req) =>
        req.id === requestId
          ? {
              ...req,
              status: newStatus,
              responseNote: note || req.responseNote,
            }
          : req
      )
    );
  };

  const handleToggleEquipmentAvailability = (equipmentId: string) => {
    setEquipmentList((prev) =>
      prev.map((eq) =>
        eq.id === equipmentId ? { ...eq, isAvailable: !eq.isAvailable } : eq
      )
    );
  };

  // Pitch competition helper: Seed simulated incoming request
  const handleSeedSampleRequest = () => {
    const sampleNames = [
      { name: 'Kiran Reddy', business: 'Reddy Earthmovers & Precast', phone: '+91 98455 77120' },
      { name: 'Gopal Hegde', business: 'Hegde Civil & Centering Works', phone: '+91 97412 34567' },
      { name: 'Mahesh Shinde', business: 'Shinde Electricals & Solar', phone: '+91 99001 88234' },
    ];
    const randomRenter = sampleNames[Math.floor(Math.random() * sampleNames.length)];
    const targetEq = equipmentList[Math.floor(Math.random() * equipmentList.length)];
    const days = Math.floor(Math.random() * 4) + 1;
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 2);

    const newId = `UDY-${Math.floor(1000 + Math.random() * 9000)}`;
    const newReq: BookingRequest = {
      id: newId,
      equipmentId: targetEq.id,
      equipmentTitle: targetEq.title,
      equipmentImageUrl: targetEq.imageUrl,
      ownerBusiness: targetEq.ownerBusiness,
      renterName: randomRenter.name,
      renterPhone: randomRenter.phone,
      renterBusiness: randomRenter.business,
      startDate: tomorrow.toISOString().split('T')[0],
      durationDays: days,
      dailyRate: targetEq.dailyRate,
      estimatedRentalTotal: targetEq.dailyRate * days,
      securityDeposit: targetEq.securityDeposit,
      estimatedGrandTotal: targetEq.dailyRate * days + targetEq.securityDeposit,
      projectNote: `Urgent requirement for a commercial site near Outer Ring Road. Will arrange tempo pickup around 8:30 AM.`,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    setBookingRequests((prev) => [newReq, ...prev]);
  };

  const handleResetDemoData = () => {
    localStorage.removeItem(STORAGE_EQUIPMENT_KEY);
    localStorage.removeItem(STORAGE_REQUESTS_KEY);
    setEquipmentList(INITIAL_EQUIPMENT_LIST);
    setBookingRequests(INITIAL_BOOKING_REQUESTS);
  };

  const pendingRequestsCount = bookingRequests.filter((r) => r.status === 'pending').length;

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-stone-900 font-sans">
      {/* Top Navigation */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        pendingRequestsCount={pendingRequestsCount}
        onOpenListModal={() => setIsListModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {currentTab === 'marketplace' && (
          <>
            <HeroSection
              onExplore={() => {
                const el = document.getElementById('marketplace-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              onListEquipment={() => setIsListModalOpen(true)}
            />

            <MarketplaceGrid
              equipmentList={equipmentList}
              onSelectItem={handleSelectItemForDetail}
              onRequestBooking={handleStartBookingFromCard}
              onOpenListModal={() => setIsListModalOpen(true)}
            />
          </>
        )}

        {currentTab === 'owner-hub' && (
          <OwnerDashboard
            equipmentList={equipmentList}
            bookingRequests={bookingRequests}
            onUpdateRequestStatus={handleUpdateRequestStatus}
            onToggleEquipmentAvailability={handleToggleEquipmentAvailability}
            onOpenListModal={() => setIsListModalOpen(true)}
            onSeedSampleRequest={handleSeedSampleRequest}
            onResetDemoData={handleResetDemoData}
            onViewItemInCatalog={(item) => {
              setCurrentTab('marketplace');
              setDetailItem(item);
            }}
          />
        )}

        {currentTab === 'how-it-works' && (
          <HowItWorksSection
            onExplore={() => setCurrentTab('marketplace')}
            onListEquipment={() => setIsListModalOpen(true)}
          />
        )}
      </main>

      {/* Equipment Detail Modal */}
      {detailItem && (
        <EquipmentDetailModal
          item={detailItem}
          onClose={() => setDetailItem(null)}
          onRequestBooking={handleStartBookingFromDetail}
        />
      )}

      {/* Renter Booking Flow Modal */}
      {bookingFlowItem && (
        <BookingRequestModal
          item={bookingFlowItem.item}
          initialDays={bookingFlowItem.initialDays}
          startDate={bookingFlowItem.startDate}
          includeOperator={bookingFlowItem.includeOperator}
          onClose={() => setBookingFlowItem(null)}
          onSubmitBooking={handleSubmitBooking}
          onNavigateToOwnerHub={() => setCurrentTab('owner-hub')}
        />
      )}

      {/* Owner Listing Modal */}
      <ListEquipmentModal
        isOpen={isListModalOpen}
        onClose={() => setIsListModalOpen(false)}
        onAddEquipment={handleAddEquipment}
        onViewCreatedItem={(newItemId) => {
          setCurrentTab('marketplace');
          const found = equipmentList.find((e) => e.id === newItemId);
          if (found) setDetailItem(found);
        }}
      />

      {/* Pitch Walkthrough Ribbon for Judges */}
      <PitchWalkthroughRibbon
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenListModal={() => setIsListModalOpen(true)}
        pendingCount={pendingRequestsCount}
      />

      {/* Footer */}
      <Footer
        onSelectTab={setCurrentTab}
        onOpenListModal={() => setIsListModalOpen(true)}
      />
    </div>
  );
}
