import React, { useState, useMemo } from 'react';
import { EquipmentItem, EquipmentCategory } from '../types';
import { EquipmentCard } from './EquipmentCard';
import { Search, SlidersHorizontal, RotateCcw, MapPin, Check } from 'lucide-react';

interface MarketplaceGridProps {
  equipmentList: EquipmentItem[];
  onSelectItem: (item: EquipmentItem) => void;
  onRequestBooking: (item: EquipmentItem) => void;
  onOpenListModal: () => void;
}

export const MarketplaceGrid: React.FC<MarketplaceGridProps> = ({
  equipmentList,
  onSelectItem,
  onRequestBooking,
  onOpenListModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<EquipmentCategory>('all');
  const [selectedLocation, setSelectedLocation] = useState<string>('all');
  const [onlyAvailable, setOnlyAvailable] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc'>('featured');

  // Extract unique locations
  const locations = useMemo(() => {
    const locSet = new Set<string>();
    equipmentList.forEach((item) => locSet.add(item.location));
    return Array.from(locSet);
  }, [equipmentList]);

  // Categories definition
  const categories: { id: EquipmentCategory; label: string }[] = [
    { id: 'all', label: 'All Equipment' },
    { id: 'construction', label: 'Construction & Workshop' },
    { id: 'agricultural', label: 'Agricultural & Land' },
    { id: 'tools', label: 'Tools & Machinery' },
    { id: 'commercial', label: 'Commercial & Cleaning' },
  ];

  // Filtered and sorted equipment
  const filteredList = useMemo(() => {
    return equipmentList
      .filter((item) => {
        // Search filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = item.title.toLowerCase().includes(q);
          const matchDesc = item.description.toLowerCase().includes(q);
          const matchOwner = item.ownerBusiness.toLowerCase().includes(q);
          const matchLoc = item.location.toLowerCase().includes(q);
          const matchSpecs = item.specifications.some((s) => s.toLowerCase().includes(q));
          if (!matchTitle && !matchDesc && !matchOwner && !matchLoc && !matchSpecs) {
            return false;
          }
        }

        // Category filter
        if (selectedCategory !== 'all' && item.category !== selectedCategory) {
          return false;
        }

        // Location filter
        if (selectedLocation !== 'all' && item.location !== selectedLocation) {
          return false;
        }

        // Availability filter
        if (onlyAvailable && !item.isAvailable) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price-asc') return a.dailyRate - b.dailyRate;
        if (sortBy === 'price-desc') return b.dailyRate - a.dailyRate;
        return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
      });
  }, [equipmentList, searchQuery, selectedCategory, selectedLocation, onlyAvailable, sortBy]);

  const hasActiveFilters =
    searchQuery.trim() !== '' ||
    selectedCategory !== 'all' ||
    selectedLocation !== 'all' ||
    onlyAvailable ||
    sortBy !== 'featured';

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedLocation('all');
    setOnlyAvailable(false);
    setSortBy('featured');
  };

  return (
    <section id="marketplace-section" className="py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-stone-200">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-900 block mb-1">
            Local Listings
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900">
            Browse Equipment for Rent
          </h2>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Verified machinery from workshops and small businesses in Bengaluru.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs text-stone-500 tabular-nums">
            Showing <strong className="text-stone-900 font-semibold">{filteredList.length}</strong> of{' '}
            {equipmentList.length} items
          </span>
          {hasActiveFilters && (
            <button
              onClick={handleResetFilters}
              className="inline-flex items-center gap-1 text-xs text-stone-600 hover:text-emerald-950 underline underline-offset-2 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              Reset filters
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="pt-6 pb-6 space-y-4">
        {/* Search Input and Location Dropdown */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-6 relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name, machine type, or specification (e.g. mixer, 15 kVA, tiller)..."
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-stone-300 rounded-lg text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-900/30 focus:border-emerald-900 transition-all shadow-2xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-600 cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>

          <div className="md:col-span-3">
            <div className="relative">
              <MapPin className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <select
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="w-full pl-10 pr-8 py-2.5 bg-white border border-stone-300 rounded-lg text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30 focus:border-emerald-900 transition-all shadow-2xs appearance-none cursor-pointer"
              >
                <option value="all">All Locations (Bengaluru)</option>
                {locations.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
              <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 text-xs">
                ▼
              </div>
            </div>
          </div>

          <div className="md:col-span-3">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full px-3 py-2.5 bg-white border border-stone-300 rounded-lg text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30 focus:border-emerald-900 transition-all shadow-2xs cursor-pointer"
            >
              <option value="featured">Sort: Featured & Recommended</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Category Segmented Controls & Availability Toggle */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-1">
          {/* Category Tabs (functional filter controls allowed as buttons) */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 w-full sm:w-auto text-xs font-medium no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-2 rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-emerald-900 text-white font-semibold shadow-2xs'
                    : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Quick Toggle for Available Now */}
          <label className="inline-flex items-center gap-2 cursor-pointer text-xs font-medium text-stone-700 shrink-0 select-none">
            <input
              type="checkbox"
              checked={onlyAvailable}
              onChange={(e) => setOnlyAvailable(e.target.checked)}
              className="w-4 h-4 rounded text-emerald-900 focus:ring-emerald-900 border-stone-300 cursor-pointer accent-emerald-900"
            />
            <span>Available Today Only</span>
          </label>
        </div>
      </div>

      {/* Grid of Equipment Cards */}
      {filteredList.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-2">
          {filteredList.map((item) => (
            <EquipmentCard
              key={item.id}
              item={item}
              onSelect={onSelectItem}
              onRequestBooking={onRequestBooking}
            />
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="text-center py-16 bg-white rounded-xl border border-stone-200/80 px-4">
          <div className="w-12 h-12 rounded-full bg-stone-100 text-stone-400 mx-auto flex items-center justify-center mb-3">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-stone-800">
            No equipment found matching your criteria
          </h3>
          <p className="text-xs text-stone-500 max-w-md mx-auto mt-1 mb-4">
            Try adjusting your search terms, changing the category, or clearing the location filter.
          </p>
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={handleResetFilters}
              className="px-4 py-2 text-xs font-semibold text-emerald-900 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors cursor-pointer"
            >
              Reset All Filters
            </button>
            <button
              onClick={onOpenListModal}
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-900 hover:bg-emerald-950 rounded-lg transition-colors cursor-pointer"
            >
              List Equipment You Own
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
