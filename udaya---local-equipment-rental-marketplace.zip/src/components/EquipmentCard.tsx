import React, { useState } from 'react';
import { EquipmentItem } from '../types';
import { MapPin, Shield, Check, Clock, ChevronRight } from 'lucide-react';

interface EquipmentCardProps {
  item: EquipmentItem;
  onSelect: (item: EquipmentItem) => void;
  onRequestBooking: (item: EquipmentItem) => void;
}

export const EquipmentCard: React.FC<EquipmentCardProps> = ({
  item,
  onSelect,
  onRequestBooking,
}) => {
  const [imageError, setImageError] = useState(false);

  return (
    <div
      onClick={() => onSelect(item)}
      className="group bg-white rounded-xl border border-stone-200/90 hover:border-emerald-900/40 shadow-xs hover:shadow-md transition-all duration-200 flex flex-col overflow-hidden cursor-pointer"
    >
      {/* Equipment Image Box */}
      <div className="relative aspect-[4/3] bg-stone-100 overflow-hidden">
        {!imageError ? (
          <img
            src={item.imageUrl}
            alt={item.title}
            onError={() => setImageError(true)}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-103"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-stone-100 text-stone-400">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              {item.categoryLabel}
            </span>
            <span className="text-xs text-stone-400 mt-1">Photo Preview</span>
          </div>
        )}

        {/* Quiet availability flag */}
        <div className="absolute top-3 left-3">
          <span
            className={`text-[11px] font-semibold px-2 py-0.5 rounded shadow-2xs backdrop-blur-xs ${
              item.isAvailable
                ? 'bg-emerald-900/90 text-white'
                : 'bg-stone-800/80 text-stone-200'
            }`}
          >
            {item.isAvailable ? 'Available Now' : 'Currently On Hire'}
          </span>
        </div>

        {item.operatorProvided && (
          <div className="absolute top-3 right-3">
            <span className="text-[11px] font-medium bg-amber-100/95 text-amber-950 px-2 py-0.5 rounded shadow-2xs">
              Operator Option
            </span>
          </div>
        )}
      </div>

      {/* Card Body */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div className="space-y-2">
          {/* Metadata line with typographic separators (anti-pill discipline) */}
          <div className="flex items-center gap-2 text-xs text-stone-500 flex-wrap">
            <span className="font-medium text-emerald-950">
              {item.categoryLabel}
            </span>
            <span aria-hidden="true">·</span>
            <span className="flex items-center gap-1 text-stone-600">
              <MapPin className="w-3 h-3 text-stone-400" />
              {item.location}
            </span>
          </div>

          {/* Title */}
          <h3 className="text-base font-bold text-stone-900 group-hover:text-emerald-900 transition-colors leading-snug">
            {item.title}
          </h3>

          {/* Punchy 1-line description */}
          <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
            {item.tagline}
          </p>

          {/* Owner Business */}
          <div className="pt-1 text-xs text-stone-500">
            <span className="text-stone-400">Listed by </span>
            <span className="font-semibold text-stone-700">{item.ownerBusiness}</span>
          </div>
        </div>

        {/* Pricing & Footer Actions */}
        <div className="pt-4 mt-4 border-t border-stone-100 flex items-end justify-between gap-3">
          <div>
            <div className="text-[11px] text-stone-500">Rental Rate</div>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-extrabold text-stone-900 tabular-nums">
                ₹{item.dailyRate.toLocaleString('en-IN')}
              </span>
              <span className="text-xs text-stone-500">/ day</span>
            </div>
            <div className="text-[11px] text-stone-400">
              ₹{item.securityDeposit.toLocaleString('en-IN')} deposit
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onRequestBooking(item);
              }}
              className="px-3 py-1.5 text-xs font-semibold text-emerald-900 hover:text-white bg-emerald-50 hover:bg-emerald-900 border border-emerald-900/20 rounded-lg transition-colors cursor-pointer"
            >
              Request
            </button>
            <div className="p-1.5 text-stone-400 group-hover:text-emerald-900 transition-colors">
              <ChevronRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
