import React, { useState } from 'react';
import { EquipmentItem, NewListingFormData } from '../types';
import { X, PlusCircle, CheckCircle, Image as ImageIcon, MapPin, IndianRupee } from 'lucide-react';

interface ListEquipmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddEquipment: (item: Omit<EquipmentItem, 'id'>) => string;
  onViewCreatedItem: (newItemId: string) => void;
}

export const ListEquipmentModal: React.FC<ListEquipmentModalProps> = ({
  isOpen,
  onClose,
  onAddEquipment,
  onViewCreatedItem,
}) => {
  if (!isOpen) return null;

  const presetImages = [
    {
      label: 'Concrete Mixer',
      url: '/src/assets/images/equipment_concrete_mixer_1794025852267.jpg',
      category: 'construction' as const,
    },
    {
      label: 'Diesel Generator',
      url: '/src/assets/images/equipment_diesel_generator_1794025853297.jpg',
      category: 'construction' as const,
    },
    {
      label: 'Power Tiller',
      url: '/src/assets/images/equipment_power_tiller_1794025853546.jpg',
      category: 'agricultural' as const,
    },
    {
      label: 'Arc Welder Rig',
      url: '/src/assets/images/equipment_arc_welder_1794025873237.jpg',
      category: 'tools' as const,
    },
    {
      label: 'Core Drilling Machine',
      url: '/src/assets/images/equipment_core_drill_1794025872879.jpg',
      category: 'tools' as const,
    },
    {
      label: 'Equipment Yard / Scaffolding',
      url: '/src/assets/images/hero_equipment_yard_1794025851706.jpg',
      category: 'construction' as const,
    },
  ];

  const [formData, setFormData] = useState<NewListingFormData>({
    title: '',
    category: 'construction',
    description: '',
    specifications: '',
    dailyRate: 750,
    securityDeposit: 2000,
    location: 'Peenya Industrial Area',
    subLocation: 'Phase 2, Bengaluru',
    ownerBusiness: '',
    ownerContact: '+91 ',
    condition: 'Good · Regularly Serviced',
    pickupTerms: 'Direct yard pickup. Tempo transport by renter.',
    imageUrl: presetImages[0].url,
    operatorProvided: false,
  });

  const [createdId, setCreatedId] = useState<string | null>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const validate = () => {
    const errs: { [key: string]: string } = {};
    if (!formData.title.trim()) errs.title = 'Please enter an equipment title';
    if (!formData.description.trim()) errs.description = 'Please describe the machine and intended use';
    if (!formData.ownerBusiness.trim()) errs.ownerBusiness = 'Please enter your business or workshop name';
    if (!formData.ownerContact.trim() || formData.ownerContact.length < 10) {
      errs.ownerContact = 'Please enter a valid phone number';
    }
    if (formData.dailyRate <= 0) errs.dailyRate = 'Daily rate must be greater than zero';
    if (formData.securityDeposit < 0) errs.securityDeposit = 'Deposit cannot be negative';

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const specsArray = formData.specifications
      .split('\n')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    const categoryLabels: { [key: string]: string } = {
      construction: 'Construction & Workshop',
      agricultural: 'Agricultural & Land',
      tools: 'Tools & Machinery',
      commercial: 'Commercial & Cleaning',
    };

    const newId = onAddEquipment({
      title: formData.title.trim(),
      category: formData.category,
      categoryLabel: categoryLabels[formData.category] || 'Equipment',
      tagline: formData.description.slice(0, 85) + '...',
      description: formData.description.trim(),
      specifications: specsArray.length > 0 ? specsArray : ['Standard commercial specifications', 'Ready for deployment'],
      dailyRate: Number(formData.dailyRate),
      securityDeposit: Number(formData.securityDeposit),
      billingUnit: 'per day',
      location: formData.location,
      subLocation: formData.subLocation,
      ownerName: 'Proprietor',
      ownerBusiness: formData.ownerBusiness.trim(),
      ownerContact: formData.ownerContact.trim(),
      isAvailable: true,
      availabilitySchedule: 'Available for immediate rental',
      condition: formData.condition,
      imageUrl: formData.imageUrl,
      pickupTerms: formData.pickupTerms,
      operatorProvided: formData.operatorProvided,
      operatorNote: formData.operatorProvided ? 'Operator available upon request' : undefined,
      isFeatured: true,
    });

    setCreatedId(newId);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div
        className="relative bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-stone-200 overflow-hidden my-6 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-stone-50/70 shrink-0">
          <div>
            <h3 className="text-base font-bold text-stone-900">
              {createdId ? 'Equipment Listed Successfully' : 'List Your Idle Equipment on Udaya'}
            </h3>
            <p className="text-xs text-stone-500">
              100% free to list · Turn idle machinery into daily earnings
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {createdId ? (
          /* Success Screen */
          <div className="p-8 space-y-6 text-center overflow-y-auto">
            <div className="w-16 h-16 bg-emerald-50 text-emerald-800 rounded-full flex items-center justify-center mx-auto border border-emerald-200">
              <CheckCircle className="w-9 h-9" />
            </div>

            <div className="space-y-2">
              <span className="text-xs font-semibold text-emerald-900 uppercase tracking-wider">
                Listing Active · ID #{createdId}
              </span>
              <h4 className="text-xl font-extrabold text-stone-900">
                "{formData.title}" is Now Live!
              </h4>
              <p className="text-xs text-stone-600 max-w-md mx-auto leading-relaxed">
                Renters in the {formData.location} cluster can now discover your equipment, see your ₹{formData.dailyRate}/day rate, and submit booking requests directly to your Owner Hub.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-3">
              <button
                onClick={onClose}
                className="w-full sm:w-auto px-5 py-2.5 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors cursor-pointer"
              >
                Done
              </button>
              <button
                onClick={() => {
                  onClose();
                  onViewCreatedItem(createdId);
                }}
                className="w-full sm:w-auto px-6 py-2.5 text-xs font-bold text-white bg-emerald-900 hover:bg-emerald-950 rounded-lg transition-all shadow-sm active:scale-[0.98] cursor-pointer"
              >
                View Listing in Marketplace
              </button>
            </div>
          </div>
        ) : (
          /* Form */
          <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto text-xs">
            {/* Equipment Name & Category */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              <div className="sm:col-span-8">
                <label className="block font-semibold text-stone-800 mb-1">
                  Equipment Name & Model <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g. Bosch GSH 11 E Demolition Breaker / 5HP Water Pump"
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30"
                />
                {errors.title && <p className="text-[11px] text-red-600 mt-1">{errors.title}</p>}
              </div>

              <div className="sm:col-span-4">
                <label className="block font-semibold text-stone-800 mb-1">
                  Category <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30"
                >
                  <option value="construction">Construction & Workshop</option>
                  <option value="agricultural">Agricultural & Land</option>
                  <option value="tools">Tools & Machinery</option>
                  <option value="commercial">Commercial & Cleaning</option>
                </select>
              </div>
            </div>

            {/* Description & Specs */}
            <div>
              <label className="block font-semibold text-stone-800 mb-1">
                Description & Capacity <span className="text-red-500">*</span>
              </label>
              <textarea
                rows={2}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe what the equipment does, engine/power specs, fuel type, and typical use cases..."
                className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30"
              />
              {errors.description && (
                <p className="text-[11px] text-red-600 mt-1">{errors.description}</p>
              )}
            </div>

            <div>
              <label className="block font-semibold text-stone-800 mb-1">
                Specifications (one per line)
              </label>
              <textarea
                rows={2}
                value={formData.specifications}
                onChange={(e) => setFormData({ ...formData, specifications: e.target.value })}
                placeholder="Motor: 1500W 230V&#10;Capacity: 25 Litres&#10;Accessories: 2 hoses included"
                className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30 font-mono"
              />
            </div>

            {/* Rates & Deposits */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 bg-stone-50 rounded-xl border border-stone-200">
              <div>
                <label className="block font-semibold text-stone-800 mb-1">
                  Daily Rental Rate (₹) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-500 font-bold">₹</span>
                  <input
                    type="number"
                    min={100}
                    step={50}
                    value={formData.dailyRate}
                    onChange={(e) => setFormData({ ...formData, dailyRate: Number(e.target.value) })}
                    className="w-full pl-8 pr-3 py-2 bg-white border border-stone-300 rounded-lg text-xs font-bold text-stone-900 tabular-nums"
                  />
                </div>
                {errors.dailyRate && <p className="text-[11px] text-red-600 mt-1">{errors.dailyRate}</p>}
              </div>

              <div>
                <label className="block font-semibold text-stone-800 mb-1">
                  Refundable Security Deposit (₹)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-500 font-bold">₹</span>
                  <input
                    type="number"
                    min={0}
                    step={100}
                    value={formData.securityDeposit}
                    onChange={(e) =>
                      setFormData({ ...formData, securityDeposit: Number(e.target.value) })
                    }
                    className="w-full pl-8 pr-3 py-2 bg-white border border-stone-300 rounded-lg text-xs font-bold text-stone-900 tabular-nums"
                  />
                </div>
                <span className="text-[10px] text-stone-500 mt-1 block">
                  Collected directly during physical pickup
                </span>
              </div>
            </div>

            {/* Owner Business Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-stone-800 mb-1">
                  Your Business / Workshop Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.ownerBusiness}
                  onChange={(e) => setFormData({ ...formData, ownerBusiness: e.target.value })}
                  placeholder="e.g. Kaveri Tool Works & Fabrication"
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30"
                />
                {errors.ownerBusiness && (
                  <p className="text-[11px] text-red-600 mt-1">{errors.ownerBusiness}</p>
                )}
              </div>

              <div>
                <label className="block font-semibold text-stone-800 mb-1">
                  Contact Mobile <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.ownerContact}
                  onChange={(e) => setFormData({ ...formData, ownerContact: e.target.value })}
                  placeholder="+91 98450 12345"
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs text-stone-900 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-900/30"
                />
                {errors.ownerContact && (
                  <p className="text-[11px] text-red-600 mt-1">{errors.ownerContact}</p>
                )}
              </div>
            </div>

            {/* Location */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-stone-800 mb-1">
                  Industrial Hub / Area
                </label>
                <select
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30"
                >
                  <option value="Peenya Industrial Area">Peenya Industrial Area</option>
                  <option value="Yeshwanthpur">Yeshwanthpur</option>
                  <option value="Rajajinagar Industrial Estate">Rajajinagar Industrial Estate</option>
                  <option value="Nelamangala Hub">Nelamangala Hub</option>
                  <option value="Dasarahalli">Dasarahalli</option>
                  <option value="Hessarghatta Road">Hessarghatta Road</option>
                  <option value="Goraguntepalya">Goraguntepalya</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-stone-800 mb-1">
                  Sub-location / Landmark
                </label>
                <input
                  type="text"
                  value={formData.subLocation}
                  onChange={(e) => setFormData({ ...formData, subLocation: e.target.value })}
                  placeholder="e.g. Near 4th Cross, Stage 1"
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30"
                />
              </div>
            </div>

            {/* Select Machinery Image */}
            <div>
              <label className="block font-semibold text-stone-800 mb-1">
                Equipment Image
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {presetImages.map((img, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setFormData({ ...formData, imageUrl: img.url })}
                    className={`relative rounded-lg overflow-hidden border-2 aspect-square cursor-pointer transition-all ${
                      formData.imageUrl === img.url
                        ? 'border-emerald-900 ring-2 ring-emerald-900/30'
                        : 'border-stone-200 hover:border-stone-400 opacity-75 hover:opacity-100'
                    }`}
                  >
                    <img src={img.url} alt={img.label} className="w-full h-full object-cover" />
                    <span className="absolute bottom-0 inset-x-0 bg-stone-900/80 text-[9px] text-white py-0.5 px-1 truncate block text-center">
                      {img.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Operator Checkbox */}
            <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-stone-700 select-none">
              <input
                type="checkbox"
                checked={formData.operatorProvided}
                onChange={(e) => setFormData({ ...formData, operatorProvided: e.target.checked })}
                className="w-4 h-4 rounded text-emerald-900 accent-emerald-900 cursor-pointer"
              />
              <span>Can provide trained operator on request</span>
            </label>

            {/* Submit */}
            <div className="pt-3 border-t border-stone-200 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-stone-600 hover:text-stone-900 font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-xs font-bold text-white bg-emerald-900 hover:bg-emerald-950 rounded-lg transition-all shadow-sm active:scale-[0.98] cursor-pointer"
              >
                Publish Equipment Listing
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
