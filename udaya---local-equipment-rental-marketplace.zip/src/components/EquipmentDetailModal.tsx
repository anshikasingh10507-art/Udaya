import React, { useState, useMemo } from 'react';
import { EquipmentItem } from '../types';
import {
  X,
  MapPin,
  Clock,
  Shield,
  CheckCircle2,
  Calendar,
  Phone,
  User,
  ArrowRight,
  Info,
  Truck
} from 'lucide-react';

interface EquipmentDetailModalProps {
  item: EquipmentItem | null;
  onClose: () => void;
  onRequestBooking: (item: EquipmentItem, initialDays: number, startDate: string, includeOperator: boolean) => void;
}

export const EquipmentDetailModal: React.FC<EquipmentDetailModalProps> = ({
  item,
  onClose,
  onRequestBooking,
}) => {
  if (!item) return null;

  // Live calculator state
  const tomorrow = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  }, []);

  const [rentalDays, setRentalDays] = useState<number>(2);
  const [startDate, setStartDate] = useState<string>(tomorrow);
  const [includeOperator, setIncludeOperator] = useState<boolean>(false);
  const [imageError, setImageError] = useState<boolean>(false);

  // Financial calculations
  const rentalSubtotal = item.dailyRate * rentalDays;
  const operatorCost = includeOperator && item.operatorProvided ? 500 * rentalDays : 0;
  const grandTotalEstimate = rentalSubtotal + operatorCost + item.securityDeposit;

  const handleStartBooking = () => {
    onRequestBooking(item, rentalDays, startDate, includeOperator);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div
        className="relative bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-stone-200 overflow-hidden my-6 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-stone-50/70 shrink-0">
          <div className="flex items-center gap-2 text-xs text-stone-500">
            <span className="font-semibold text-emerald-900">{item.categoryLabel}</span>
            <span aria-hidden="true">·</span>
            <span>Ref #{item.id}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-200/60 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="overflow-y-auto p-6 space-y-8 flex-1">
          {/* Header & Main Info */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Visual Box */}
            <div className="lg:col-span-5 relative rounded-xl overflow-hidden bg-stone-100 border border-stone-200 aspect-[4/3]">
              {!imageError ? (
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  onError={() => setImageError(true)}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-stone-400 text-sm">
                  {item.categoryLabel}
                </div>
              )}
              <div className="absolute bottom-3 left-3">
                <span
                  className={`text-xs font-semibold px-2.5 py-1 rounded shadow-sm backdrop-blur-xs ${
                    item.isAvailable
                      ? 'bg-emerald-900/90 text-white'
                      : 'bg-stone-800/90 text-stone-200'
                  }`}
                >
                  {item.isAvailable ? 'Available for Pickup' : 'Booked · In Use'}
                </span>
              </div>
            </div>

            {/* Title, Rates & Owner Badging */}
            <div className="lg:col-span-7 space-y-3">
              <div className="flex items-center gap-2 text-xs text-stone-500">
                <span className="flex items-center gap-1 font-medium text-stone-700">
                  <MapPin className="w-3.5 h-3.5 text-emerald-900" />
                  {item.location}
                </span>
                <span aria-hidden="true">·</span>
                <span>{item.subLocation}</span>
              </div>

              <h2 className="text-2xl font-extrabold text-stone-900 leading-snug">
                {item.title}
              </h2>

              <p className="text-sm text-stone-600 leading-relaxed">
                {item.description}
              </p>

              {/* Verified Owner Card */}
              <div className="pt-2 border-t border-stone-100 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-stone-50 border border-stone-200/80">
                  <span className="text-stone-400 block text-[11px]">Owner / Small Business</span>
                  <div className="font-bold text-stone-800 text-sm mt-0.5">
                    {item.ownerBusiness}
                  </div>
                  <div className="text-stone-500 mt-0.5">
                    Proprietor: {item.ownerName}
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-stone-50 border border-stone-200/80">
                  <span className="text-stone-400 block text-[11px]">Condition & Maintenance</span>
                  <div className="font-semibold text-stone-800 text-sm mt-0.5">
                    {item.condition}
                  </div>
                  <div className="text-stone-500 mt-0.5 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-stone-400" />
                    {item.availabilitySchedule}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Specifications and Pickup Terms */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-4 border-t border-stone-200">
            <div>
              <h4 className="text-sm font-bold text-stone-900 uppercase tracking-wider mb-3">
                Key Technical Specifications
              </h4>
              <ul className="space-y-2 text-xs text-stone-700">
                {item.specifications.map((spec, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-800 shrink-0 mt-0.5" />
                    <span>{spec}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-sm font-bold text-stone-900 uppercase tracking-wider mb-3">
                Pickup & Logistics Terms
              </h4>
              <div className="space-y-2.5 text-xs text-stone-600">
                <div className="flex items-start gap-2">
                  <Truck className="w-4 h-4 text-stone-400 shrink-0 mt-0.5" />
                  <span>
                    <strong>Pickup Method: </strong>
                    {item.pickupTerms}
                  </span>
                </div>
                <div className="flex items-start gap-2">
                  <Shield className="w-4 h-4 text-stone-400 shrink-0 mt-0.5" />
                  <span>
                    <strong>Refundable Security Deposit: </strong>
                    ₹{item.securityDeposit.toLocaleString('en-IN')} held by owner upon physical handover, refunded upon clean return.
                  </span>
                </div>
                {item.operatorNote && (
                  <div className="p-2.5 rounded bg-amber-50/70 border border-amber-200/70 text-amber-950">
                    <strong>Note: </strong>
                    {item.operatorNote}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Interactive Live Duration & Price Calculator */}
          <div className="p-5 rounded-xl bg-stone-50 border border-stone-300 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h4 className="text-sm font-bold text-stone-900">
                  Rental Cost Calculator
                </h4>
                <p className="text-xs text-stone-500">
                  Calculate the transparent estimate before submitting your request to the owner.
                </p>
              </div>
              <div className="text-right">
                <span className="text-xs text-stone-500">Base Rate: </span>
                <span className="text-base font-bold text-stone-900 tabular-nums">
                  ₹{item.dailyRate.toLocaleString('en-IN')}
                </span>
                <span className="text-xs text-stone-500"> / day</span>
              </div>
            </div>

            {/* Inputs: Start Date & Duration */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-2">
              <div className="sm:col-span-5">
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Start Date
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="date"
                    min={tomorrow}
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-white border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-900/30"
                  />
                </div>
              </div>

              <div className="sm:col-span-7">
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Rental Duration (Days)
                </label>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {[1, 2, 3, 5, 7, 14].map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setRentalDays(d)}
                      className={`px-3 py-2 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                        rentalDays === d
                          ? 'bg-emerald-900 text-white shadow-2xs'
                          : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200'
                      }`}
                    >
                      {d} {d === 1 ? 'day' : 'days'}
                    </button>
                  ))}
                  <div className="flex items-center gap-1 ml-auto">
                    <span className="text-xs text-stone-500">Custom:</span>
                    <input
                      type="number"
                      min={1}
                      max={60}
                      value={rentalDays}
                      onChange={(e) => setRentalDays(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-14 px-2 py-1.5 bg-white border border-stone-300 rounded text-xs text-center font-bold text-stone-900"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Optional Operator Toggle if applicable */}
            {item.operatorProvided && (
              <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-stone-700 pt-1 select-none">
                <input
                  type="checkbox"
                  checked={includeOperator}
                  onChange={(e) => setIncludeOperator(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-900 accent-emerald-900 cursor-pointer"
                />
                <span>Include experienced machine operator (+₹500/day)</span>
              </label>
            )}

            {/* Calculated Breakdown Line */}
            <div className="pt-3 border-t border-stone-200 text-xs space-y-1.5">
              <div className="flex justify-between text-stone-600">
                <span>
                  Equipment Rental ({rentalDays} {rentalDays === 1 ? 'day' : 'days'} × ₹{item.dailyRate})
                </span>
                <span className="font-semibold text-stone-800 tabular-nums">
                  ₹{rentalSubtotal.toLocaleString('en-IN')}
                </span>
              </div>

              {includeOperator && item.operatorProvided && (
                <div className="flex justify-between text-stone-600">
                  <span>Operator assistance ({rentalDays} days × ₹500)</span>
                  <span className="font-semibold text-stone-800 tabular-nums">
                    ₹{operatorCost.toLocaleString('en-IN')}
                  </span>
                </div>
              )}

              <div className="flex justify-between text-stone-500">
                <span>Refundable Security Deposit (held on handover)</span>
                <span className="font-medium text-stone-700 tabular-nums">
                  ₹{item.securityDeposit.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="flex justify-between items-baseline pt-2 border-t border-stone-300 text-stone-900 font-bold">
                <span className="text-sm">Estimated Total Commitment</span>
                <div className="text-right">
                  <span className="text-lg text-emerald-950 tabular-nums">
                    ₹{grandTotalEstimate.toLocaleString('en-IN')}
                  </span>
                  <span className="block text-[10px] text-stone-400 font-normal">
                    Includes ₹{item.securityDeposit.toLocaleString('en-IN')} refundable deposit
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Sticky Bottom Action Footer */}
        <div className="p-4 sm:p-5 bg-white border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-stone-500 text-center sm:text-left">
            <span className="font-medium text-stone-700">Direct booking request</span>
            <span className="hidden sm:inline"> · No upfront payment required on Udaya</span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="flex-1 sm:flex-initial px-4 py-2.5 text-xs font-semibold text-stone-700 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors cursor-pointer"
            >
              Back to Catalog
            </button>
            <button
              onClick={handleStartBooking}
              className="flex-1 sm:flex-initial px-6 py-2.5 text-xs font-bold text-white bg-emerald-900 hover:bg-emerald-950 rounded-lg shadow-sm hover:shadow transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
            >
              <span>Request Booking for {rentalDays} {rentalDays === 1 ? 'Day' : 'Days'}</span>
              <ArrowRight className="w-4 h-4 text-amber-400" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
